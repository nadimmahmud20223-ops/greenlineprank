# Green Line Prank (Android Studio project)

এটি একটি নিরাপদ visual prank: শুধু Android overlay-তে সবুজ লাইন আঁকে; ডিসপ্লে/হার্ডওয়্যার পরিবর্তন করে না।

## Build
1. Android Studio-তে এই ফোল্ডারটি Open করুন।
2. Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
3. তৈরি APK ফোনে ইনস্টল করুন।

## ফোনে চালু করা
1. অ্যাপ খুলে Overlay Permission দিন।
2. START চাপুন।
3. বন্ধ করতে STOP চাপুন।

## সীমাবদ্ধতা
- Android/Samsung-এর Keyguard, Always On Display, boot logo, secure/system screens-এ overlay দেখানো Android নিজেই আটকাতে পারে। Lock screen-এ কাজের নিশ্চয়তা নেই।
- Restart-এর পরে auto-start Android-এর ব্যাটারি/ব্যাকগ্রাউন্ড নীতি, permission এবং firmware-এর ওপর নির্ভর করে। Settings > Apps > Green Line Prank > Battery থেকে background use allow করুন, যদি অপশন থাকে।
- এই starter project-এ reboot receiver আছে, কিন্তু Android-এর boot restrictions ও Samsung firmware-এর কারণে সব ডিভাইসে স্বয়ংক্রিয়ভাবে চালু হবে এমন নিশ্চয়তা নেই।
- কোনো real display damage বা system setting পরিবর্তন করা হয় না।
