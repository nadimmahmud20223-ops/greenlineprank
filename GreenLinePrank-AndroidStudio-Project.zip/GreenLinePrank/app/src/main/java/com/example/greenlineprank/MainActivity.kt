package com.example.greenlineprank

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("prank", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        layout.addView(TextView(this).apply {
            text = "Green Line Prank\n\nএটি শুধু স্ক্রিনে সবুজ লাইন দেখায়; ডিসপ্লে নষ্ট করে না।"
            textSize = 21f
            gravity = Gravity.CENTER
        })
        fun addButton(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }
        addButton("১. Overlay Permission দিন") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Permission already enabled", Toast.LENGTH_SHORT).show()
        }
        addButton("START – Green Lines") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "আগে Overlay Permission দিন", Toast.LENGTH_LONG).show()
            } else {
                p.edit().putBoolean("enabled", true).apply()
                startService(Intent(this, LineService::class.java))
                Toast.makeText(this, "Green lines started", Toast.LENGTH_SHORT).show()
            }
        }
        addButton("STOP – সবুজ লাইন বন্ধ") {
            p.edit().putBoolean("enabled", false).apply()
            stopService(Intent(this, LineService::class.java))
            Toast.makeText(this, "Green lines stopped", Toast.LENGTH_SHORT).show()
        }
        addButton("Restart-এর পর Auto Start: ON") {
            p.edit().putBoolean("enabled", true).apply()
            Toast.makeText(this, "Auto-start preference saved. START-ও চাপুন।", Toast.LENGTH_LONG).show()
        }
        setContentView(layout)
    }
}
