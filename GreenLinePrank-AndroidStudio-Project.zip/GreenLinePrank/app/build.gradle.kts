plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.greenlineprank"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.greenlineprank"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
